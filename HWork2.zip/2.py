n = int(input()) 
found_zero = False  # Переменная, указывающая был ли найден ноль

for i in range(n):
    num = int(input())  # Считываем очередное число
    if num == 0:
        found_zero = True
        break  # Если найден ноль, прерываем цикл

if found_zero:
    print("YES")
else:
    print("NO")
