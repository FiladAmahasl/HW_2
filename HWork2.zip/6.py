N = int(input())

# Инициализируем сумму и переменную для вычисления факториала
sum = 1
factorial = 1

for i in range(1, N + 1):
    factorial *= i
    sum += 1 / factorial

print(f"{sum:.5f}")