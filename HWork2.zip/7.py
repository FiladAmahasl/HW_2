import math

x = int(input())
count = 0 

# ищем делители от 1 до sqrt(x), увеличивая счетчик на 2 за каждый найденный делитель
for i in range(1, int(math.sqrt(x)) + 1):
    if x % i == 0:
        count += 2

# если x является квадратом целого числа, то sqrt(x) будет считаться дважды, поэтому нужно уменьшить счетчик на 1
if int(math.sqrt(x))**2 == x:
    count -= 1

print(count)
